let inputPeso = document.querySelector("#inputPeso");
let inputAltura = document.querySelector("#inputAltura");
let btExibir = document.querySelector("#btExibir");
let h3Resultado = document.querySelector("#h3Resultado");

function CalcularIMC(){
    let peso = Number(inputPeso.value)
    let altura = Number(inputAltura.value)
    let IMC;

    IMC = peso / (altura*altura)

    if( IMC < 18.5 ){
        h3Resultado.textContent = "Abaixo do peso "+IMC
    }
    if( IMC > 18.5 && IMC < 24.9){
        h3Resultado.textContent = "peso Normal "+IMC
    }
    if( IMC > 25 && IMC < 29.9){
        h3Resultado.textContent = "Sobre peso "+IMC
    }
    if( IMC > 30 && IMC < 34.9){
        h3Resultado.textContent = "Obesidade grau 1 "+IMC
    }
    if( IMC > 35 && IMC < 39.9){
        h3Resultado.textContent = "Obesidade grau 2 "+IMC
    }
     
    if( IMC > 40){
        h3Resultado.textContent = "→ Obesidade grau 3 "+IMC
    }

}

btExibir.onclick = function(){
    CalcularIMC();
}