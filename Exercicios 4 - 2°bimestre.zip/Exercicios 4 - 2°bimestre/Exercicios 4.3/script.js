let inputInicial = document.querySelector("#inputInicial");
let inputTaxa = document.querySelector("#inputTaxa");
let inputMeses = document.querySelector("#inputMeses");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function CalcularTaxa(){
    let ValorInicial = Number(inputInicial.value);
    let tempo = Number(inputMeses.value);
    let taxa = Number(inputTaxa.value);
    let ValorFinal

    ValorFinal = ValorInicial * Math.pow((1 + (taxa/100)), tempo)

    h3Resultado.textContent = "vai ter o valor de R$"+ValorFinal.toFixed(2)+" reais"

}

btCalcular.onclick = function(){
    CalcularTaxa();
}