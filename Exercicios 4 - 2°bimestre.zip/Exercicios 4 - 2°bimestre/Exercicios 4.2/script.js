let inputAno = document.querySelector("#inputAno");
let btVerificar = document.querySelector("#btVerificar");
let h3Resultado = document.querySelector("#h3Resultado");

function VerficarIdade(){
    let ano = Number(inputAno.value);
    let idade;

    idade = 2025 - ano

    if( idade < 12 ){
        h3Resultado.textContent = "Infantil "+ idade+" Anos"
    }
    if( idade > 12 && idade < 17 ){
        h3Resultado.textContent = "Adolescente "+ idade+" Anos"
    }
    if( idade > 18 && idade < 59){
        h3Resultado.textContent = "Adulto "+ idade+" Anos"
    }
    if( idade > 60 ){
        h3Resultado.textContent = "Senior "+ idade+" Anos"
    }

}

btVerificar.onclick = function(){
    VerficarIdade();
}